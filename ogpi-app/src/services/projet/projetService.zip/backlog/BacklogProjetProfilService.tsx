import { BacklogProjetProfil, OrderUpdateItem } from "../../../types/projet/backlog/BacklogProjet.tsx";
import { Profil } from "../../../types/profil/Profil.tsx";

/**
 * BacklogProjetProfilService
 * Correspond à BacklogProjetProfilRepository.java
 * Gère les profils définis dans un backlog et leurs rattachements à des collaborateurs.
 * Endpoints base : /api/projet/backlog/profil
 */
export class BacklogProjetProfilService {
  private readonly api: any;

  constructor(api: any) {
    this.api = api;
  }

  // ─────────────────────────────────────────────
  // PROFILS
  // ─────────────────────────────────────────────

  /** POST /api/projet/backlog/profil */
  async create(payload: {
    name: string;
    desc?: string;
    tjm: number;
    order: number;
    backlogId: number;
  }): Promise<BacklogProjetProfil> {
    const response = await this.api.post("/api/projet/backlog/profil", payload);
    return response.data;
  }

  /** PUT /api/projet/backlog/profil/{id} */
  async update(
    id: number,
    payload: { name: string; desc?: string; tjm: number }
  ): Promise<BacklogProjetProfil> {
    const response = await this.api.put(`/api/projet/backlog/profil/${id}`, payload);
    return response.data;
  }

  /** DELETE /api/projet/backlog/profil/{id} */
  async delete(id: number): Promise<void> {
    await this.api.delete(`/api/projet/backlog/profil/${id}`);
  }

  /** GET /api/projet/backlog/profil/{id} */
  async getById(id: number): Promise<BacklogProjetProfil> {
    const response = await this.api.get(`/api/projet/backlog/profil/${id}`);
    return response.data;
  }

  /**
   * GET /api/projet/backlog/profil/{id}/with-collaborateurs
   * Retourne le profil avec ses collaborateurs résolus.
   */
  async getByIdWithCollaborateurs(id: number): Promise<BacklogProjetProfil> {
    const response = await this.api.get(`/api/projet/backlog/profil/${id}/with-collaborateurs`);
    return response.data;
  }

  /** GET /api/projet/backlog/profil/by-backlog/{backlogId} */
  async getByBacklogId(backlogId: number): Promise<BacklogProjetProfil[]> {
    const response = await this.api.get(`/api/projet/backlog/profil/by-backlog/${backlogId}`);
    return response.data;
  }

  /**
   * GET /api/projet/backlog/profil/by-backlog/{backlogId}/with-collaborateurs
   * Retourne tous les profils d'un backlog avec leurs collaborateurs (2 requêtes côté serveur).
   */
  async getByBacklogIdWithCollaborateurs(backlogId: number): Promise<BacklogProjetProfil[]> {
    const response = await this.api.get(
      `/api/projet/backlog/profil/by-backlog/${backlogId}/with-collaborateurs`
    );
    return response.data;
  }

  /** PUT /api/projet/backlog/profil/order */
  async updateOrder(items: OrderUpdateItem[]): Promise<void> {
    await this.api.put("/api/projet/backlog/profil/order", items);
  }

  // ─────────────────────────────────────────────
  // COLLABORATEURS
  // ─────────────────────────────────────────────

  /** GET /api/projet/backlog/profil/{profilId}/collaborateurs */
  async getCollaborateurs(profilId: number): Promise<Profil[]> {
    const response = await this.api.get(
      `/api/projet/backlog/profil/${profilId}/collaborateurs`
    );
    return response.data;
  }

  /**
   * PUT /api/projet/backlog/profil/{profilId}/collaborateurs
   * Remplace la liste complète des collaborateurs d'un profil.
   */
  async replaceCollaborateurs(profilId: number, collaborateurIds: number[]): Promise<void> {
    await this.api.put(
      `/api/projet/backlog/profil/${profilId}/collaborateurs`,
      collaborateurIds
    );
  }

  /**
   * POST /api/projet/backlog/profil/{profilId}/collaborateurs/{collaborateurId}
   * Ajoute un collaborateur au profil (idempotent — ON CONFLICT DO NOTHING côté serveur).
   */
  async addCollaborateur(profilId: number, collaborateurId: number): Promise<void> {
    await this.api.post(
      `/api/projet/backlog/profil/${profilId}/collaborateurs/${collaborateurId}`
    );
  }

  /**
   * DELETE /api/projet/backlog/profil/{profilId}/collaborateurs/{collaborateurId}
   * Retire un collaborateur d'un profil.
   */
  async removeCollaborateur(profilId: number, collaborateurId: number): Promise<void> {
    await this.api.delete(
      `/api/projet/backlog/profil/${profilId}/collaborateurs/${collaborateurId}`
    );
  }
}