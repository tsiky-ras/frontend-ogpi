import { BacklogLine } from "../../../types/lead/Backlog/Backlog.tsx";
import { BacklogProjetLineProfil, OrderUpdateItem } from "../../../types/projet/backlog/BacklogProjet.tsx";

/**
 * BacklogProjetLineService
 * Correspond à BacklogProjetLineRepository.java
 * Endpoints base : /api/projet/backlog/line
 */
export class BacklogProjetLineService {
  private readonly api: any;

  constructor(api: any) {
    this.api = api;
  }

  /** POST /api/projet/backlog/line */
  async create(payload: {
    epic?: string;
    userStory?: string;
    description?: string;
    resultat?: string;
    order: number;
    phaseId: number;
  }): Promise<BacklogLine> {
    const response = await this.api.post("/api/projet/backlog/line", payload);
    return response.data;
  }

  /** PUT /api/projet/backlog/line/{id} */
  async update(
    id: number,
    payload: {
      epic?: string;
      userStory?: string;
      description?: string;
      resultat?: string;
      phaseId: number;
      order: number;
    }
  ): Promise<BacklogLine> {
    const response = await this.api.put(`/api/projet/backlog/line/${id}`, payload);
    return response.data;
  }

  /** DELETE /api/projet/backlog/line/{id} */
  async delete(id: number): Promise<void> {
    await this.api.delete(`/api/projet/backlog/line/${id}`);
  }

  /** GET /api/projet/backlog/line/{id} */
  async getById(id: number): Promise<BacklogLine> {
    const response = await this.api.get(`/api/projet/backlog/line/${id}`);
    return response.data;
  }

  /** PUT /api/projet/backlog/line/order */
  async updateOrder(items: OrderUpdateItem[]): Promise<void> {
    await this.api.put("/api/projet/backlog/line/order", items);
  }
}

/**
 * BacklogProjetLineProfilService
 * Correspond à BacklogProjetLineProfilRepository.java
 * Gère les volumes par profil sur chaque ligne du backlog.
 * Endpoints base : /api/projet/backlog/line-profil
 */
export class BacklogProjetLineProfilService {
  private readonly api: any;

  constructor(api: any) {
    this.api = api;
  }

  /** POST /api/projet/backlog/line-profil */
  async create(payload: {
    volume: number;
    lineId: number;
    profilId: number;
  }): Promise<BacklogProjetLineProfil> {
    const response = await this.api.post("/api/projet/backlog/line-profil", payload);
    return response.data;
  }

  /** PUT /api/projet/backlog/line-profil/{id} */
  async update(
    id: number,
    payload: { volume: number; lineId: number; profilId: number }
  ): Promise<BacklogProjetLineProfil> {
    const response = await this.api.put(`/api/projet/backlog/line-profil/${id}`, payload);
    return response.data;
  }

  /** DELETE /api/projet/backlog/line-profil/{id} */
  async delete(id: number): Promise<void> {
    await this.api.delete(`/api/projet/backlog/line-profil/${id}`);
  }

  /** GET /api/projet/backlog/line-profil/{id} */
  async getById(id: number): Promise<BacklogProjetLineProfil> {
    const response = await this.api.get(`/api/projet/backlog/line-profil/${id}`);
    return response.data;
  }

  /** GET /api/projet/backlog/line-profil/by-line/{lineId} */
  async getAllByLineId(lineId: number): Promise<BacklogProjetLineProfil[]> {
    const response = await this.api.get(`/api/projet/backlog/line-profil/by-line/${lineId}`);
    return response.data;
  }

  /** GET /api/projet/backlog/line-profil/by-backlog/{backlogId} */
  async getAllByBacklogId(backlogId: number): Promise<BacklogProjetLineProfil[]> {
    const response = await this.api.get(
      `/api/projet/backlog/line-profil/by-backlog/${backlogId}`
    );
    return response.data;
  }
}