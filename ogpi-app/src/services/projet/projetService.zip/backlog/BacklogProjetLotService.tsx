import { BacklogLot } from "../../../types/lead/Backlog/Backlog.tsx";
import { OrderUpdateItem } from "../../../types/projet/backlog/BacklogProjet.tsx";

/**
 * BacklogProjetLotService
 * Correspond à BacklogProjetLotRepository.java
 * Endpoints base : /api/projet/backlog/lot
 */
export class BacklogProjetLotService {
  private readonly api: any;

  constructor(api: any) {
    this.api = api;
  }

  /** POST /api/projet/backlog/lot */
  async create(payload: {
    name: string;
    desc?: string;
    order: number;
    backlogId: number;
  }): Promise<BacklogLot> {
    const response = await this.api.post("/api/projet/backlog/lot", payload);
    return response.data;
  }

  /** PUT /api/projet/backlog/lot/{id} */
  async update(id: number, payload: { name: string; desc?: string }): Promise<BacklogLot> {
    const response = await this.api.put(`/api/projet/backlog/lot/${id}`, payload);
    return response.data;
  }

  /** DELETE /api/projet/backlog/lot/{id} */
  async delete(id: number): Promise<void> {
    await this.api.delete(`/api/projet/backlog/lot/${id}`);
  }

  /** GET /api/projet/backlog/lot/{id} */
  async getById(id: number): Promise<BacklogLot> {
    const response = await this.api.get(`/api/projet/backlog/lot/${id}`);
    return response.data;
  }

  /** GET /api/projet/backlog/lot/by-backlog/{backlogId} */
  async getByBacklogId(backlogId: number): Promise<BacklogLot[]> {
    const response = await this.api.get(`/api/projet/backlog/lot/by-backlog/${backlogId}`);
    return response.data;
  }

  /** PUT /api/projet/backlog/lot/order — met à jour les ordres en batch */
  async updateOrder(items: OrderUpdateItem[]): Promise<void> {
    await this.api.put("/api/projet/backlog/lot/order", items);
  }
}