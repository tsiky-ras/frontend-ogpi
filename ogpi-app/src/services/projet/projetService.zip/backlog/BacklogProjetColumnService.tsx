import {
  BacklogColumn,
  BacklogLineColumnValue,
  CreateBacklogColumnRequest,
  UpdateBacklogColumnRequest,
  UpsertBacklogLineColumnValueRequest,
} from "../../../types/projet/backlog/BacklogProjet.tsx";

/**
 * BacklogProjetColumnService
 * Correspond à BacklogProjetColumnRepository.java
 *
 * Gère les colonnes dynamiques (table backlog_column_) rattachées à un sprint,
 * et leurs valeurs par ligne (table backlog_line_column_value).
 *
 * Endpoints base : /api/projet/backlog/column
 */
export class BacklogProjetColumnService {
  private readonly api: any;

  constructor(api: any) {
    this.api = api;
  }

  // ─────────────────────────────────────────────
  // COLONNES
  // ─────────────────────────────────────────────

  /** POST /api/projet/backlog/column */
  async createColumn(payload: CreateBacklogColumnRequest): Promise<BacklogColumn> {
    const response = await this.api.post("/api/projet/backlog/column", payload);
    return response.data;
  }

  /** PUT /api/projet/backlog/column/{id} */
  async updateColumn(id: number, payload: UpdateBacklogColumnRequest): Promise<BacklogColumn> {
    const response = await this.api.put(`/api/projet/backlog/column/${id}`, payload);
    return response.data;
  }

  /**
   * DELETE /api/projet/backlog/column/{id}
   * Supprime la colonne et toutes ses valeurs (CASCADE en BDD).
   */
  async deleteColumn(id: number): Promise<void> {
    await this.api.delete(`/api/projet/backlog/column/${id}`);
  }

  /** GET /api/projet/backlog/column/{id} */
  async getColumnById(id: number): Promise<BacklogColumn> {
    const response = await this.api.get(`/api/projet/backlog/column/${id}`);
    return response.data;
  }

  /** GET /api/projet/backlog/column/by-sprint/{sprintId} */
  async getColumnsBySprintId(sprintId: number): Promise<BacklogColumn[]> {
    const response = await this.api.get(`/api/projet/backlog/column/by-sprint/${sprintId}`);
    return response.data;
  }

  // ─────────────────────────────────────────────
  // VALEURS
  // ─────────────────────────────────────────────

  /**
   * POST /api/projet/backlog/column/value
   * Crée ou met à jour la valeur d'une colonne pour une ligne donnée (upsert côté serveur).
   */
  async upsertValue(payload: UpsertBacklogLineColumnValueRequest): Promise<BacklogLineColumnValue> {
    const response = await this.api.post("/api/projet/backlog/column/value", payload);
    return response.data;
  }

  /**
   * DELETE /api/projet/backlog/column/value/{id}
   * Supprime une valeur par son ID.
   */
  async deleteValue(id: number): Promise<void> {
    await this.api.delete(`/api/projet/backlog/column/value/${id}`);
  }

  /**
   * GET /api/projet/backlog/column/value/by-line/{lineId}
   * Retourne toutes les valeurs d'une ligne, avec la définition de colonne résolue.
   */
  async getValuesByLineId(lineId: number): Promise<BacklogLineColumnValue[]> {
    const response = await this.api.get(
      `/api/projet/backlog/column/value/by-line/${lineId}`
    );
    return response.data;
  }
}