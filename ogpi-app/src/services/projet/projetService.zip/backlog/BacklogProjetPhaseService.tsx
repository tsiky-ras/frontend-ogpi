import { BacklogPhase } from "../../../types/lead/Backlog/Backlog.tsx";
import {
  BacklogSprint,
  BacklogDelivrableProjet,
  CreateBacklogSprintRequest,
  UpdateBacklogSprintRequest,
  CreateBacklogDelivrableRequest,
  UpdateBacklogDelivrableRequest,
  OrderUpdateItem,
} from "../../../types/projet/backlog/BacklogProjet.tsx";

/**
 * BacklogProjetPhaseService
 * Correspond à BacklogProjetPhaseRepository.java
 * Gère les phases, leurs sprints et leurs livrables.
 * Endpoints base : /api/projet/backlog/phase
 */
export class BacklogProjetPhaseService {
  private readonly api: any;

  constructor(api: any) {
    this.api = api;
  }

  // ─────────────────────────────────────────────
  // PHASES
  // ─────────────────────────────────────────────

  /** POST /api/projet/backlog/phase */
  async create(payload: {
    name: string;
    order: number;
    lotId: number;
    dateDebut?: string;
    dateFin?: string;
  }): Promise<BacklogPhase> {
    const response = await this.api.post("/api/projet/backlog/phase", payload);
    return response.data;
  }

  /** PUT /api/projet/backlog/phase/{id} */
  async update(
    id: number,
    payload: { name: string; dateDebut?: string; dateFin?: string }
  ): Promise<BacklogPhase> {
    const response = await this.api.put(`/api/projet/backlog/phase/${id}`, payload);
    return response.data;
  }

  /** DELETE /api/projet/backlog/phase/{id} */
  async delete(id: number): Promise<void> {
    await this.api.delete(`/api/projet/backlog/phase/${id}`);
  }

  /** GET /api/projet/backlog/phase/{id} */
  async getById(id: number): Promise<BacklogPhase> {
    const response = await this.api.get(`/api/projet/backlog/phase/${id}`);
    return response.data;
  }

  /**
   * GET /api/projet/backlog/phase/{id}/full
   * Retourne la phase complète : lignes + sprints (avec colonnes) + livrables.
   */
  async getFullById(id: number): Promise<BacklogPhase> {
    const response = await this.api.get(`/api/projet/backlog/phase/${id}/full`);
    return response.data;
  }

  /** PUT /api/projet/backlog/phase/order */
  async updateOrder(items: OrderUpdateItem[]): Promise<void> {
    await this.api.put("/api/projet/backlog/phase/order", items);
  }

  // ─────────────────────────────────────────────
  // SPRINTS
  // ─────────────────────────────────────────────

  /** GET /api/projet/backlog/phase/{phaseId}/sprint */
  async getSprints(phaseId: number): Promise<BacklogSprint[]> {
    const response = await this.api.get(`/api/projet/backlog/phase/${phaseId}/sprint`);
    return response.data;
  }

  /** POST /api/projet/backlog/phase/{phaseId}/sprint */
  async createSprint(payload: CreateBacklogSprintRequest): Promise<BacklogSprint> {
    const response = await this.api.post(
      `/api/projet/backlog/phase/${payload.phaseId}/sprint`,
      payload
    );
    return response.data;
  }

  /** PUT /api/projet/backlog/sprint/{id} */
  async updateSprint(id: number, payload: UpdateBacklogSprintRequest): Promise<BacklogSprint> {
    const response = await this.api.put(`/api/projet/backlog/sprint/${id}`, payload);
    return response.data;
  }

  /** DELETE /api/projet/backlog/sprint/{id} */
  async deleteSprint(id: number): Promise<void> {
    await this.api.delete(`/api/projet/backlog/sprint/${id}`);
  }

  /** PUT /api/projet/backlog/sprint/order */
  async updateSprintOrder(items: OrderUpdateItem[]): Promise<void> {
    await this.api.put("/api/projet/backlog/sprint/order", items);
  }

  // ─────────────────────────────────────────────
  // LIVRABLES
  // ─────────────────────────────────────────────

  /** GET /api/projet/backlog/phase/{phaseId}/livrable */
  async getDeliverablesByPhaseId(phaseId: number): Promise<BacklogDelivrableProjet[]> {
    const response = await this.api.get(`/api/projet/backlog/phase/${phaseId}/livrable`);
    return response.data;
  }

  /** GET /api/projet/backlog/sprint/{sprintId}/livrable */
  async getDeliverablesBySprintId(sprintId: number): Promise<BacklogDelivrableProjet[]> {
    const response = await this.api.get(`/api/projet/backlog/sprint/${sprintId}/livrable`);
    return response.data;
  }

  /** POST /api/projet/backlog/phase/{phaseId}/livrable */
  async createDeliverable(payload: CreateBacklogDelivrableRequest): Promise<BacklogDelivrableProjet> {
    const response = await this.api.post(
      `/api/projet/backlog/phase/${payload.phaseId}/livrable`,
      payload
    );
    return response.data;
  }

  /** PUT /api/projet/backlog/livrable/{id} */
  async updateDeliverable(
    id: number,
    payload: UpdateBacklogDelivrableRequest
  ): Promise<BacklogDelivrableProjet> {
    const response = await this.api.put(`/api/projet/backlog/livrable/${id}`, payload);
    return response.data;
  }

  /** DELETE /api/projet/backlog/livrable/{id} */
  async deleteDeliverable(id: number): Promise<void> {
    await this.api.delete(`/api/projet/backlog/livrable/${id}`);
  }

  /** PUT /api/projet/backlog/livrable/order */
  async updateDeliverableOrder(items: OrderUpdateItem[]): Promise<void> {
    await this.api.put("/api/projet/backlog/livrable/order", items);
  }
}