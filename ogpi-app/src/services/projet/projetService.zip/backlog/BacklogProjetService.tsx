import { CreateBacklogForProjetRequest } from "../../../types/projet/backlog/BacklogProjet.tsx";
import { Backlog } from "../../../types/lead/Backlog/Backlog.tsx";

/**
 * BacklogProjetService
 * Correspond à BacklogProjetRepository.java
 * Endpoints base : /api/projet/backlog
 */
export class BacklogProjetService {
  private readonly api: any;

  constructor(api: any) {
    this.api = api;
  }

  /**
   * Crée un backlog rattaché directement à un projet (sans lead).
   * POST /api/projet/backlog
   */
  async createForProjet(payload: CreateBacklogForProjetRequest): Promise<Backlog> {
    const response = await this.api.post("/api/projet/backlog", payload);
    return response.data;
  }

  /**
   * Récupère l'en-tête du backlog d'un projet (sans hiérarchie complète).
   * GET /api/projet/backlog/by-projet/{projetId}
   */
  async getHeaderByProjetId(projetId: number): Promise<Backlog | null> {
    try {
      const response = await this.api.get(`/api/projet/backlog/by-projet/${projetId}`);
      return response.data;
    } catch (err: any) {
      if (err?.response?.status === 404) return null;
      throw err;
    }
  }

  /**
   * Charge le backlog complet d'un projet :
   * profils (avec collaborateurs), lots → phases → lignes + profils de ligne, sprints, livrables.
   * GET /api/projet/backlog/full/by-projet/{projetId}
   */
  async getFullByProjetId(projetId: number): Promise<Backlog | null> {
    try {
      const response = await this.api.get(`/api/projet/backlog/full/by-projet/${projetId}`);
      return response.data;
    } catch (err: any) {
      if (err?.response?.status === 404) return null;
      throw err;
    }
  }

  /**
   * Charge le backlog complet par son ID.
   * GET /api/projet/backlog/{id}/full
   */
  async getFullById(backlogId: number): Promise<Backlog> {
    const response = await this.api.get(`/api/projet/backlog/${backlogId}/full`);
    return response.data;
  }

  /**
   * Met à jour le backlog (nom, description).
   * PUT /api/projet/backlog/{id}
   */
  async update(
    backlogId: number,
    payload: { name: string; desc?: string }
  ): Promise<Backlog> {
    const response = await this.api.put(`/api/projet/backlog/${backlogId}`, payload);
    return response.data;
  }

  /**
   * Rattache un backlog existant (créé depuis un lead) à un projet.
   * PUT /api/projet/backlog/{backlogId}/attach/{projetId}
   */
  async attachToProjet(backlogId: number, projetId: number): Promise<void> {
    await this.api.put(`/api/projet/backlog/${backlogId}/attach/${projetId}`);
  }

  /**
   * Supprime un backlog.
   * DELETE /api/projet/backlog/{id}
   */
  async delete(backlogId: number): Promise<void> {
    await this.api.delete(`/api/projet/backlog/${backlogId}`);
  }
}